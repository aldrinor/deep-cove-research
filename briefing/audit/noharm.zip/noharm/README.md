# NOHARM: Audit Pack

- Benchmark: NOHARM, ARISE Network (MAST). Kit: https://github.com/ARISENetwork/mast, benchmarks/donoharm. Cases and rubrics © 2026 ARISE Network, CC BY 4.0. Public set: 330 items = 30 cases across 10 specialties, each in its original form plus perturbed variants.
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on, as in the product; one attempt per item.
- Grader: the official NOHARM judge, unmodified: matching model gemini-3-flash-preview, review model gemini-3.5-flash.
- Score: 80.0 = 100 x mean(F1_weighted) over all 330 items, the official headline metric (severity-weighted F1 over the actions in Kit's plan). Severity-weighted precision 87.3; recall 78.3.
- Severe-harm flag: Severe_rate is the official per-item flag (1 = the plan contains at least one action graded as severe harm, by commission or omission). Official metric value over the 330 items: 0.185 (61 of 330 items).
- Files: results.jsonl and results.csv (item_id = the official NOHARM item id; kit_answer = Kit's delivered answer; F1_weighted, Precision_weighted, Recall_weighted, Severe_rate = official per-item metrics; grade = F1_weighted); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
