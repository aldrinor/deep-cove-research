# noharm: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5 | 65.0 | NOHARM leaderboard (clinicalbenchmarks.ai) and ARISE MAST page data, read November 2026 | NOHARM; leaderboard rows also include held-out cases | as published | the official NOHARM judge |
| Anthropic | Opus 5 | 74.6 | same | same | same | same |
| OpenAI | GPT-5.6 Sol | 70.1 | same | same | same | same |
| Human Expert | 101 US physicians | 42.2 | NOHARM paper, arXiv 2512.01241 | 100 base cases | conventional resources | the NOHARM metric |
