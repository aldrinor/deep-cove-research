"""Letter accuracy: the answer letter Kit gave (kit_letter in results.jsonl) against the gold letter of the
official MedQA test file; grade 1 when equal. MedQA ships no scoring script; its paper metric is exact letter accuracy."""
import json, sys
rows = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
print(round(100 * sum(r["grade"] for r in rows) / len(rows), 1))
