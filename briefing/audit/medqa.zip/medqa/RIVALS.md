# medqa: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Opus 4.8 | 95.0 | arXiv 2607.10849, Table 2 (12 July 2026) | the same 1,273 US 4-option test questions | zero-shot, no tools | accuracy |
| OpenAI | GPT-5.4 | 96.1 | Vals AI, vals.ai/benchmarks/medqa | Vals AI's 2,000-question MedQA sample | no tools | accuracy |
| Note | GPT-5.6 Luna | 94.7 | arXiv 2611.00460 | the same 1,273 questions | as published | accuracy (a newer OpenAI model, not shown in the table) |
