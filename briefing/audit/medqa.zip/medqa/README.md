# MedQA (USMLE, 4 Options): Audit Pack

- Benchmark: MedQA, Jin et al. (https://github.com/jind11/MedQA): the full US 4-option test set, 1,273 questions (Hugging Face GBaker/MedQA-USMLE-4-options, test split).
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on; one attempt per question. An automated audit of every search Kit made found no question searched by its own text.
- Grader: exact match of Kit's answer letter against the gold letter (MedQA's published metric is letter accuracy); script in grader/letter_match.py, no model involved.
- Score: 95.1 (1,211 of 1,273 correct). Recompute: python3 grader/letter_match.py results.jsonl.
- Files: results.jsonl and results.csv (item_id = medqa-test-<row index in the test split, counting from 0>; kit_answer = Kit's delivered answer; kit_letter = the letter Kit chose; grade 1 = correct); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
