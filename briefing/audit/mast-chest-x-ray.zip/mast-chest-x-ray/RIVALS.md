# mast-chest-x-ray: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5 | 51.0 | ARISE MAST page data, read November 2026 | MAST radiology set (IU X-Ray plus MIMIC-CXR and CheXpert Plus); Kit ran the 590 public IU X-Ray examinations | as published | MAST's normalized CRIMSON, whose formula MAST does not publish; Kit's 67.8 uses (CRIMSON + 1) ÷ 2 × 100, so the scales differ |
| Anthropic | Opus 5 | 43.3 | same | same | same | same |
| OpenAI | GPT-5.6 Sol | 51.7 | same | same | same | same |
