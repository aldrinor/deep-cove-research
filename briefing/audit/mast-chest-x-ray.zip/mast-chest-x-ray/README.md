# MAST Chest X-Ray Report Generation (IU X-Ray Set): Audit Pack

- Benchmark: the IU X-Ray (Open-i) part of the chest X-ray report task used in the ARISE Network MAST leaderboard: all 590 test studies of the public ReXrank IU X-Ray split. (MAST's radiology set also includes MIMIC-CXR and CheXpert Plus, which are distributed under separate credentialed-access agreements.)
- System: Kit Think with its image understanding, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: each study's frontal and lateral images sent with the request (both images for 589 studies, one image for 1); images only, no clinical history, as in MAST; Kit writes the Findings and Impression; one attempt per study.
- Grader: CRIMSON (Rajpurkar Lab, https://github.com/rajpurkarlab/CRIMSON, MIT, commit 07e33315) with its official judge model rajpurkarlab/medgemma-4b-it-crimson, run unmodified.
- Score conversion: CRIMSON scores range from -1 to 1 (1 = a perfect report; 0 = no more informative than a normal-study template) and are reported on a 0-100 scale as (score + 1) / 2 x 100.
- Score: 67.8 = (mean CRIMSON score 0.357 + 1) / 2 x 100 over 588 studies. For 2 studies the CRIMSON judge model returned output that its parser rejects; scoring both at the lowest possible CRIMSON score gives 67.6. Recompute: average the grade column of results.jsonl (blank = unscored), add 1, divide by 2, multiply by 100.
- Files: results.jsonl and results.csv (item_id = the IU X-Ray study id; kit_answer = Kit's Findings and Impression; grade = CRIMSON score, -1 to 1; grade_0_100 = the same on the 0-100 scale); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
