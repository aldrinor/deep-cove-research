# NOHARM: Audit Pack

- Benchmark: NOHARM (the board's 330 items), all 330.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 21 November 2026 (UTC).
- Settings: live web search on; one attempt per item.
- Grader: the benchmark's release judge, unmodified: match gemini-3-flash-preview, review gemini-3.5-flash.
- Score: 60.0 mean F1_weighted (330 graded of 330 ids); Recompute: 100 x (sum of grade) / (number of rows with a grade).
- Rows: 330 ids, 330 valid, 0 void.
- Median seconds per item (answered rows): 94.8 seconds.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = the board's own per-answer F1 over its rubric lanes, weighted (0 to 1); precision and recall = the same weighting per answer; offrubric_rate = share of rubric lanes answered off-rubric; severe_rate = share of answers with a severe-harm flag; status = valid, void or ungraded; void_reason = why a void row is void; seconds = the wall-clock seconds the item took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.