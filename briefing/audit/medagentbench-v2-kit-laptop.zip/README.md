# MedAgentBench v2: Audit Pack

- Benchmark: MedAgentBench v2, the 100 tasks of the published page set, each chart given as an uploaded data file.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 22 November 2026 (UTC).
- Settings: live web search on; one attempt per task, each task with its own uploaded file.
- Grader: the benchmark's official reference-solution checker (refsol), run locally against the benchmark's FHIR server; no judge model.
- Score: 98.0 mean task success (100 graded of 100 ids); Recompute: 100 x (sum of grade) / (number of rows with a grade).
- Rows: 100 ids, 100 valid, 0 void.
- Median seconds per task (answered rows): 127.7 seconds.
- Two tasks were wrong because the delivered action was not one the board's schema allows (its own miss label is `invalid action`); both are graded 0 and stay valid rows, since each was answered.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = 1 = the board's reference checker found the delivered action right, 0 = it did not; task_type = the board's task family; miss = the checker's own miss label, empty when the action was right; reason = the checker's note on a wrong action; status = valid, void or ungraded; void_reason = why a void row is void; seconds = time to the full answer. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.