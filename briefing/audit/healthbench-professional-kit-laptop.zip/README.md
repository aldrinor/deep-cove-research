# HealthBench Professional: Audit Pack

- Benchmark: HealthBench Professional (the board's 525 items), all 525.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 21 November 2026 (UTC).
- Settings: live web search on; one attempt per item.
- Grader: the board's official grader, run with its own judge model (gpt-5.4), unmodified.
- Score: 53.7 mean length-adjusted credit (500 graded of 525 ids); Recompute: 100 x (sum of grade) / (number of rows with a grade).
- Rows: 525 ids, 500 valid, 0 void, 25 ungraded.
- Median seconds per item (answered rows): 66.0 seconds.
- The grader read 500 of the 525 ids; the 25 it did not read are ungraded here and the score is the mean over the 500 it read.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = the board's own length-adjusted rubric credit for the answer, clipped to 0 to 1; empty when the grader did not read the answer; score_raw = the grader's credit before the length adjustment; correct = the board's own pass flag; answer_chars = the length of the delivered answer; status = valid, void or ungraded; void_reason = why a void row is void; seconds = the wall-clock seconds the item took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.