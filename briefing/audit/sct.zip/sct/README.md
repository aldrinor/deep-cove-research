# SCT-Bench (Script Concordance Testing): Audit Pack

- Benchmark: SCT-Bench public set, https://github.com/SCT-Bench/sctpublic (MIT) at commit c2843137: all 174 public items.
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on; one attempt per item.
- Grader: the official scoring code, unmodified (modeling.py safe_parse_response and sct_score): credit for each rating equals the share of the expert panel that chose it, normalised to the panel's modal answer. All 174 of Kit's ratings parsed.
- Score: 72.8 = 100 x mean(grade) over 174 items. Recompute from results.jsonl.
- Files: results.jsonl and results.csv (item_id = the item's number in the sctpublic item file, 1–174; kit_answer = Kit's delivered answer; rating = the rating Kit gave, -2 to +2; grade = panel credit, 0 to 1); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
