# sct: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5 | 61.3 | ARISE MAST page data, read November 2026 | the full 750-item SCT set (576 held out); Kit ran the 174 public items | as published | MAST |
| Anthropic | Opus 5 | 62.2 | same | same | same | same |
| OpenAI | GPT-5.6 Sol | 64.2 | same | same | same | same |
