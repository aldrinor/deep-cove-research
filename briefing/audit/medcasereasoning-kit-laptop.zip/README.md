# MedCaseReasoning: Audit Pack

- Benchmark: MedCaseReasoning (the board's 837 cases), all 837.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 21 November 2026 (UTC).
- Settings: live web search on; one attempt per case, except 34 cases first answered through an expired test-account login were asked again, and the later answer is the one graded.
- Grader: the board's own judge, openai/gpt-4.1, unmodified.
- Score: 59.5 mean rank-1 accuracy (837 graded of 837 ids); Recompute: 100 x (sum of grade) / (number of rows with a grade).
- Rows: 837 ids, 837 valid, 0 void.
- Median seconds per case (answered rows): 92.9 seconds.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = 1 = the judge scored the answer's rank-1 diagnosis correct, 0 = it did not; gold = the case's published diagnosis; top10 = whether the diagnosis was anywhere in the answer's top ten; judge_verdict = the judge's own status for the answer; status = valid, void or ungraded; void_reason = why a void row is void; seconds = the wall-clock seconds the item took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.

Disclosure: open web; the turn read the case's own published report on 315 of 837 cases; rank-1 accuracy is 39% (185 of 475) where no own source was met.