# medagentbench-v1: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Opus 4.8 | 70.2 | Kwok et al., “LLM-as-a-Verifier”, arXiv 2607.05391 v2, Table 3 (July 2026) | MedAgentBench v1; the paper does not state how many of the 300 tasks it ran | a fixed agent setup, as published | the benchmark's reference checker, as reported by the paper |
| OpenAI | GPT-5.5 | 65.1 | same paper and table | as above | as above | as above |
