# MedAgentBench v1: Audit Pack

- Benchmark: MedAgentBench, Stanford Machine Learning Group (Jiang et al., arXiv 2501.14654). Code: https://github.com/stanfordmlgroup/MedAgentBench (MIT). Task file: test_data_v2.json, all 300 tasks (10 task types x 30).
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: the benchmark's FHIR record tools (GET/POST) against the benchmark's own de-identified record server; one attempt per task (pass@1).
- Grader: the benchmark's reference checker refsol.py, unmodified, applied to the record-server state after Kit's actions. SHA-256 of the copy used: 96ea676acc8abc136d71bdb152ee309c156b5bbdd3b38de9ae37ca014536b85a (official download link in the MedAgentBench README).
- Score: 94.3 (283 of 300 tasks pass). Recompute: 100 x (rows with grade = 1) / 300 over results.jsonl.
- Files: results.jsonl and results.csv (item_id = the task id in test_data_v2.json; kit_answer = Kit's final FINISH(...) output; grade 1 = pass, 0 = fail); actions.jsonl (every request Kit sent to the record server, in order; server responses are not included); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
