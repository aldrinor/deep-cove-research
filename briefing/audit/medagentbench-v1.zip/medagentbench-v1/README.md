# MedAgentBench v1: Audit Pack

- Benchmark: MedAgentBench, Stanford Machine Learning Group (Jiang et al., arXiv 2501.14654). Code: https://github.com/stanfordmlgroup/MedAgentBench (MIT). Task file: test_data_v2.json, our 100 tasks (10 cases x the 10 task types; ids in ids.txt).
- System: Kit Think, engine head recall14 (code 1f6236347) with the live b8u314i switch set plus 7 record switches (not yet a live release), Deep Cove Intelligence, Inc. Run Dates: 19 November 2026 (UTC).
- Settings: each task's patient record is printed by our converter as a paper chart PDF and uploaded to Kit as a file; Kit answers in the benchmark's action format, the benchmark's checker grades those requests and the FINISH as if they had been sent to its record server, and one attempt per task is made (pass@1).
- Timing: median 84 s per task (p90 117 s), from upload to the delivered answer.
- Grader: the benchmark's reference checker refsol.py, unmodified. SHA-256 of the copy used: 96ea676acc8abc136d71bdb152ee309c156b5bbdd3b38de9ae37ca014536b85a (official download link in the MedAgentBench README).
- Score: 97.0 (97 of 100 tasks pass). Recompute: 100 x (rows with grade = 1) / 100 over results.jsonl.
- Files: results.jsonl and results.csv (item_id = the task id in test_data_v2.json; kit_answer = Kit's final FINISH(...) output; grade 1 = pass, 0 = fail); actions.jsonl (every request Kit wrote in its answer, in order; server responses are not included); ids.txt (the 100 task ids); run.json (engine, code, run dates, counts, timings); SHA256SUMS.
- Previous run: previous-run/ holds the earlier published pack, unchanged (300 tasks through the benchmark's record tools, 283 pass = 94.3); it is not part of this score.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
