# healthbench-professional: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5.2 | 68.1 | Artificial Analysis, artificialanalysis.ai/evaluations/healthbench-professional (Fable 5.2 row, 9 November 2026) | all 525 conversations | independent evaluation | judge GPT-5.4 at low effort, length-adjusted, as for Kit |
| Anthropic | Opus 5.5 | 59.9 | Artificial Analysis, same page (board of 19 October 2026) | same | same | same |
| OpenAI | GPT-6.1 Sol | 65.1 | same | same | same | same |
| OpenAI | GPT-6 Astra | 66.0 | same | same | same | same |
| Human Expert | specialty-matched physicians | 43.7 | HealthBench Professional paper, arXiv 2604.27470 | all 525 tasks | unlimited time and internet search, without AI | the HealthBench Professional grader |
