# HealthBench Professional: Audit Pack

- Benchmark: HealthBench Professional, OpenAI (paper arXiv 2604.27470; grader code https://github.com/openai/simple-evals at commit 652c89d0). All 525 public conversations (420 held-out and 105 dev).
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on; one answer per conversation.
- Grader: the official GRADER_TEMPLATE from simple-evals, unchanged; judge GPT-5.4 at reasoning effort low; one judge call per rubric line.
- Score: 61.9 = 100 x mean(length-adjusted score) over 525. Per item: raw = rubric points met / total positive points; length-adjusted = raw - 2.94e-5 x (answer characters - 2000), as specified in the paper (section 4.1); the board mean is clipped to [0, 1]. Raw mean, before length adjustment: 67.6.
- Files: results.jsonl and results.csv (item_id = the official conversation id; kit_answer = Kit's delivered answer; score_raw; grade = length-adjusted score; rubric_line_verdicts = the judge's met / not-met verdict for each rubric line, in rubric order); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
