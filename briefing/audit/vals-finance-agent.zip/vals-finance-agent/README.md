# Vals Finance Agent (Public Set): Audit Pack

- Benchmark: Vals AI Finance Agent benchmark (https://www.vals.ai), all 27 tasks of the public set.
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on; one attempt per task.
- Grader: GPT-4.1 checks each rubric line of the task against Kit's answer, majority of 3 judge rounds per task. The official Vals harness (github.com/vals-ai/finance-agent-v2) ships the agent runner only and no grader, so the judge is named here.
- Metric: mean rubric score with partial credit per rubric line: each task scores the share of its rubric lines met (0 to 1), and the board score is the mean over the 27 tasks, x 100. Tasks meeting every rubric line: 8 of 27 (all_lines_met). Tasks meeting every must-pass line: 11 of 27 (all_must_pass_lines_met).
- Rivals: Vals AI reports task accuracy on its 449-task private test set, so the rival figures are not like for like with this partial-credit mean; see RIVALS.md.
- Score: 73.8. Recompute: 100 x mean(grade) over results.jsonl.
- Files: results.jsonl and results.csv (item_id = finv2-<position in the public task file>; kit_answer = Kit's delivered answer; grade = share of rubric lines met; all_lines_met; all_must_pass_lines_met; rubric_line_verdicts = the judge's verdict for each rubric line, in rubric order, with must_pass marked); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
