# vals-finance-agent: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5.2 | 69.5 | Vals AI Finance Agent v2.1 results (11 November 2026) | Vals AI's 449-task private test set; Kit ran the 27 public tasks | as published | Vals AI task accuracy; Kit's 73.8 is a mean rubric score with partial credit, so the two are not like for like |
| Anthropic | Opus 5.5 | 67.9 | same | same | same | same |
| OpenAI | GPT-6.1 Sol | 61.8 | same | same | same | same |
| OpenAI | GPT-6 Astra | 60.4 | same | same | same | same |
