# GPQA Diamond: Audit Pack

- Benchmark: GPQA Diamond (the board's 198 items), all 198.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 21 November 2026 (UTC).
- Settings: live web search on; one attempt per item, except 28 items whose first answer came back void (busy) were asked again, and the later answer is the one graded.
- Grader: the benchmark's own exact-match scorer, run locally; no judge model is called.
- Score: 83.3 mean accuracy (198 graded of 198 ids); Recompute: 100 x (sum of grade) / (number of rows with a grade).
- Rows: 198 ids, 198 valid, 0 void.
- Median seconds per question (answered rows): 65.0 seconds.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = 1 = the extracted letter matched the gold letter, 0 = it did not; extracted = the letter the answer settled on; status = valid, void or ungraded; void_reason = why a void row is void; seconds = the wall-clock seconds the item took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.