# BrokenArXiv (MathArena): Audit Pack

- Benchmark: BrokenArXiv, MathArena (ETH Zurich SRI Lab; https://matharena.ai): all 53 items of the set, posed with MathArena's official instructions.
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on; one attempt per item.
- Grader: GPT-4.1 scores each answer 0–3 against the item's reference with MathArena's BrokenArXiv rubric; answers cut off by the time limit, and refusals, score 0.
- Score: 88.7 = 100 x total points / 159 (141 of 159 points; 37 items at full marks). Recompute from judge_points in results.jsonl.
- Files: results.jsonl and results.csv (item_id = the item's id in the MathArena set; kit_answer = Kit's delivered answer; judge_points; max_points = 3); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
