# brokenarxiv: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5.2 | 80.5 | MathArena, matharena.ai (BrokenArXiv, September 2026 set) | the same September 2026 set | as published | MathArena's own grading; Kit is graded by a GPT-4.1 judge under MathArena's rubric |
| Anthropic | Opus 5.5 | 77.3 | MathArena overall BrokenArXiv figure | pooled across MathArena's sets | as published | same |
| OpenAI | GPT-6.1 Sol | 83.1 | MathArena overall BrokenArXiv figure | pooled across MathArena's sets | as published | same |
