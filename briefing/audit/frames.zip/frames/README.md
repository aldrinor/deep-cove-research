# FRAMES: Audit Pack

- Benchmark: FRAMES (Google; dataset google/frames-benchmark on Hugging Face; paper arXiv 2409.12941).
- Items in this pack: 824, one row per item, in ids-file order.
- Sample rule: All 824 items of the board's published set, in the order of data/frames/ids.full (sha256 950a2f18a64cd01e8b3c784348f2ca04c80113a89a71614400f8ac072d306e1c; order seed 20261115-frames-full-order), asked once each.
- System: Kit Think, Deep Cove Intelligence, Inc.
- Run date: 16-17 November 2026 (UTC).
- Engine: benchmark engine = G1 target: code 12h/appfix1114-routes5 @ 2a1901e2d (base release-b8u300m 0c3842de2, queued as b8u302) + live_config.b8u300m.full.json + G1-GLOBAL-1116.set; set sha256 16b2f3b25a237035210f9e00c73d4a7db95b872c205393fd62c984e0b70af68f; guard sha256 690ea2aac979fd022e7bf2a55b45c2883304701fa632e713da1392feeb514b16 (1,027 hosts).
- Settings: live web search on; pages that publish the benchmark's questions or answers were blocked; one attempt per item; up to 3 tries on a failed call.
- Grader: the FRAMES auto-rater prompt, run by GPT-4.1 (OpenAI), one call per answer.
- Score: 86.4% (711 of 823 counted: 823 graded and 0 forfeited). Recompute: 100 x (items with grade 1) / (items graded + items forfeited), from results.jsonl.
- Valid: 823. Void: 1. Forfeit: 0. Graded: 823 of the valid. Forfeited items count as wrong; void items (no answer delivered) are in the pack but not in the score.
- Void reasons: busy 1.
- Seconds per item: median 43.9 s, p90 219.9 s, over the valid items.
- Route split (path.playbook): think_loop 823 items, 86.4%.
- Cost: $0.010921 per answered item (the app's own per-item cost summed over the valid items, divided by the valid items).
- 402 re-asks: 21 items of this board were re-asked after the service key refused a call with 402 (payment required); those rows are void with reason harness_key_402 and the later answer is the one counted.
- Files: results.jsonl and results.csv carry item_id, kit_answer, grade, status, seconds, route, label, judge_verdict. kit_answer is the answer Kit delivered, unchanged; grade 1 = the answer was marked correct; status is valid, forfeit or void; seconds is the item's own turn time; route is the path the app took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored from its last delivery; no answer was edited or removed after grading.
