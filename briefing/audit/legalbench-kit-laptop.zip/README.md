# LegalBench: Audit Pack

- Benchmark: LegalBench (the board's 200 items), all 200.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 21 November 2026 (UTC).
- Settings: live web search on; one attempt per item, though 18 rows were asked again after an earlier attempt was marked void; re-asked rows: the later answer is graded.
- Grader: the benchmark's official exact-match scorer, run locally; no judge model.
- Score: 70.6 mean accuracy (197 graded of 200 ids); Recompute: 100 x (sum of grade) / (number of rows with a grade).
- Rows: 200 ids, 197 valid, 3 void.
- Median seconds per item (answered rows): 70.8 seconds.
- Balanced accuracy on the same rows is 79.1, the board's own figure; the score above is plain accuracy over the 197 graded ids.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = 1 = the extracted answer matched the gold label exactly, 0 = it did not; status = valid, void or ungraded; void_reason = why a void row is void; seconds = the wall-clock seconds the item took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.