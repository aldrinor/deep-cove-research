# MedQA: Audit Pack

- Benchmark: MedQA (the board's 1,273 items), all 1,273.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 21-22 November 2026 (UTC).
- Settings: live web search on; one attempt per item.
- Grader: the benchmark's own exact-match scorer, run locally; no judge model is called.
- Score: 91.0 mean accuracy (1273 graded of 1273 ids); Recompute: 100 x (sum of grade) / (number of rows with a grade).
- Rows: 1273 ids, 1273 valid, 0 void.
- Median seconds per question (answered rows): 66.6 seconds.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = 1 = the answer's letter matched the gold letter, 0 = it did not; letter = the option letter the answer gave; gold = the board's gold letter; status = valid, void or ungraded; void_reason = why a void row is void; seconds = the wall-clock seconds the item took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.