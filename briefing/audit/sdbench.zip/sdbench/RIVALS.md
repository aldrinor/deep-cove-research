# sdbench: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Opus 5.5 | 93.5 | Deep Cove run, November 2026 | the same 100 public CPC-Bench cases | the same SDBench framework, gatekeeper and judge as Kit | the SDBench judge, 4 or 5 of 5 counts as correct |
| OpenAI | GPT-6.1 Sol | 97.5 | Deep Cove run, November 2026 | same | same | same |
