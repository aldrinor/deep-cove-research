# SDBench Sequential Diagnosis: Audit Pack

- Benchmark harness: SDBench, Microsoft AI (MIT licence), default configuration: GPT-5 gatekeeper, GPT-5 judge, judge prompt v4_reasoning_with_tests.
- Cases: the 100 NEJM case records of the CPC-Bench public release (Buckley et al., arXiv 2509.12194), prepared for the SDBench harness by a written, deterministic rule: the confirmed final diagnosis is the record's anatomical or pathological diagnosis. In 10 cases the summary Kit sees opened with a sentence stating that diagnosis; that sentence was removed from Kit's view only (the gatekeeper keeps the full record). The case ids are listed in grader/case_edits.md.
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: Kit asks questions and orders tests only through the SDBench gatekeeper; live web search on; one attempt per case per run.
- Count: 100 cases x 2 runs = 200 scored runs.
- Grader: the SDBench judge (GPT-5) scores Kit's final diagnosis against the confirmed diagnosis on its 1–5 scale; a score of 4 or 5 counts as correct, as in SDBench.
- Score: 88.0 (176 of 200 runs correct). Recompute: 100 x (rows with grade = 1) / 200; diagnosis_score holds the judge's 1–5 score for every run.
- Files: results.jsonl and results.csv (item_id = the case's NEJM identifier; repeat = run 1 or 2; kit_answer = Kit's final diagnosis; diagnosis_score; grade); actions.jsonl (every test Kit ordered through the gatekeeper, in order; gatekeeper replies are not included); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
