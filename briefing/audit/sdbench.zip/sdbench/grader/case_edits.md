# SDBench case edits

The summary Kit sees opened with a sentence stating the final diagnosis in these cases; that sentence was removed from Kit's view only (the gatekeeper keeps the full record).

- NEJMcpc079007: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc079013: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc030010: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc030039: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc1411439: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc1314242: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc0802849: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc1111576: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc0707893: diagnosis-stating sentence removed from the agent-visible summary
- NEJMcpc049022: diagnosis-stating sentence removed from the agent-visible summary
