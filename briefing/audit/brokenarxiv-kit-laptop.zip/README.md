# BrokenArXiv: Audit Pack

- Benchmark: BrokenArXiv (the board's 53 items), all 53.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 21 November 2026 (UTC).
- Settings: live web search on; one attempt per item.
- Grader: the board's own judge, gpt-4.1, unmodified.
- Score: 54.1 mean points (86 of 159 possible points); Recompute: 100 x (sum of points) / (sum of max_points).
- Rows: 53 ids, 53 valid, 0 void.
- Median seconds per item (answered rows): 126.0 seconds.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = the judge's points for the answer over the item's max points; points = the judge's points; max_points = the item's maximum; cutoff, refusal and run_limit = the run's own flags for an answer cut off, refused or ended by the run limit (each zeroes the points); status = valid, void or ungraded; void_reason = why a void row is void; seconds = the wall-clock seconds the item took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.