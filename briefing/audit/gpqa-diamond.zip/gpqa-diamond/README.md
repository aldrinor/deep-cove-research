# GPQA Diamond: Audit Pack

- Benchmark: GPQA, Rein et al. (arXiv 2311.12022; https://github.com/idavidrein/gpqa): the full Diamond set, 198 questions (simple-evals gpqa_diamond.csv).
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on; one attempt per question; answer options presented in the fixed order recorded per item (option_order).
- Grader: letter accuracy against the correct option, no model involved.
- Score: 90.9 (180 of 198). Recompute: 100 x (rows with grade = 1) / 198.
- Files: results.jsonl and results.csv (record_id = GPQA's Record ID; question_sha256 = SHA-256 of the question text exactly as sent, options included; option_order = which original option sat at each letter; kit_letter = the letter Kit chose; grade 1 = correct); SHA256SUMS. No question text is included, in line with the GPQA authors' request.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
