# gpqa-diamond: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5.1 | 93.4 | Vals AI, read November 2026 | GPQA Diamond, 198 questions | no tools | accuracy |
| OpenAI | GPT-6.1 Sol | 95.4 | a published third-party comparison table that does not document its setup | GPQA Diamond | not documented | accuracy |
| OpenAI | GPT-6 Astra | 96.3 | Artificial Analysis, read November 2026 | GPQA Diamond | no tools | accuracy |
