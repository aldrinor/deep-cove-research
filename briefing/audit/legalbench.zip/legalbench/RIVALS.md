# legalbench: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5.1 | 88.5 | Vals AI LegalBench results (13 October 2026) | Vals AI's own task selection; Kit ran a seeded 200-question sample across 29 tasks | no tools | Vals AI |
| OpenAI | GPT-5.6 Sol | 87.0 | same | same | same | same |
