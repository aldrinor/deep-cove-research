# LegalBench: Audit Pack

- Benchmark: LegalBench, Guha et al. (https://github.com/HazyResearch/legalbench): 200 questions drawn at random (seed 20261101) across 29 LegalBench tasks.
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on; one attempt per question.
- Grader: LegalBench's exact-match scoring of the extracted answer.
- Score: 79.5 accuracy (159 of 200); balanced accuracy 80.5. Recompute: 100 x (rows with grade = 1) / 200.
- Files: results.jsonl and results.csv (item_id = legalbench-<task>-<row index in that task's test file>; kit_answer = Kit's delivered answer; extracted = the label scored; grade 1 = correct); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
