# CPC-Bench Differential Diagnosis, First Answer: Audit Pack

- Benchmark: CPC-Bench, Buckley et al. (arXiv 2509.12194), differential-diagnosis task on the 100 cases of the public release (NEJM Case Records of the Massachusetts General Hospital).
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: live web search on; one attempt per case. An automated audit of every search and page Kit read found no case whose own published record was reached.
- Grader: the official CPC-Bench scoring code with its judge model GPT-4.1. Kit's ranked list is matched against the confirmed final diagnosis; the case counts as correct when the matching diagnosis is ranked first.
- Score: 54.0 (54 of 100). Recompute: 100 x (rows with grade = 1) / 100. diagnosis_rank gives the position of the matching diagnosis in Kit's list (blank = not in the list); the confirmed diagnosis appears in Kit's list for 75 of 100 cases.
- Files: results.jsonl and results.csv (item_id = the case's NEJM identifier; kit_answer = Kit's ranked diagnoses; grade; diagnosis_rank; diagnosis_presence); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
