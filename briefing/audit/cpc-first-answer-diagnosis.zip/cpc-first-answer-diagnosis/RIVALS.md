# cpc-first-answer-diagnosis: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Opus 5 | 58.0 | ARISE MAST page data, read November 2026 | MAST's own case set, top-1 accuracy, reported at about ±9 points | as published | MAST |
| OpenAI | GPT-5.6 Sol | 59.0 | same | same | same | same |
