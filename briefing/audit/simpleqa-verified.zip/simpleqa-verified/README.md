# SimpleQA Verified: Audit Pack

- Benchmark: SimpleQA Verified (Google DeepMind; 1,000 short questions, each with one short fact as the answer).
- Items in this pack: 1,000, one row per item, in ids-file order.
- Sample rule: All 1,000 items of the board's published set, in the order of data/simpleqa/ids.full (sha256 747b60fcb24fb8fe4eab1c31eeed9ac573570dc500a6bda9ec6e90fcbacfb849; order seed 20261115-simpleqa-full-order), asked once each.
- System: Kit Think, Deep Cove Intelligence, Inc.
- Run date: 16-17 November 2026 (UTC).
- Engine: benchmark engine = G1 target: code 12h/appfix1114-routes5 @ 2a1901e2d (base release-b8u300m 0c3842de2, queued as b8u302) + live_config.b8u300m.full.json + G1-GLOBAL-1116.set; set sha256 16b2f3b25a237035210f9e00c73d4a7db95b872c205393fd62c984e0b70af68f; guard sha256 690ea2aac979fd022e7bf2a55b45c2883304701fa632e713da1392feeb514b16 (1,027 hosts).
- Settings: live web search on; pages that publish the benchmark's questions or answers were blocked; one attempt per item; up to 3 tries on a failed call.
- Grader: the official SimpleQA grader prompt, run by GPT-4.1 (OpenAI), one call per answer.
- Score: 94.1% (938 of 997 counted: 997 graded and 0 forfeited). Recompute: 100 x (items with grade 1) / (items graded + items forfeited), from results.jsonl.
- Valid: 997. Void: 3. Forfeit: 0. Graded: 997 of the valid. Forfeited items count as wrong; void items (no answer delivered) are in the pack but not in the score.
- Void reasons: busy 3.
- Seconds per item: median 23.1 s, p90 67.5 s, over the valid items.
- Route split (path.playbook): think_loop 997 items, 94.1%.
- Official metric: F1 94.7 (accuracy 94.1 over 997 graded, accuracy given attempted 95.2; not attempted 12). F1 = 2 x accuracy x accuracy-given-attempted / (their sum), from the grader's CORRECT / INCORRECT / NOT_ATTEMPTED labels.
- Cost: $0.008381 per answered item (the app's own per-item cost summed over the valid items, divided by the valid items).
- 402 re-asks: 19 items of this board were re-asked after the service key refused a call with 402 (payment required); those rows are void with reason harness_key_402 and the later answer is the one counted.
- Files: results.jsonl and results.csv carry item_id, kit_answer, grade, status, seconds, route, label, judge_verdict. kit_answer is the answer Kit delivered, unchanged; grade 1 = the answer was marked correct; status is valid, forfeit or void; seconds is the item's own turn time; route is the path the app took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored from its last delivery; no answer was edited or removed after grading.
