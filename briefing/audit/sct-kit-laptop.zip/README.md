# SCT: Audit Pack

- Benchmark: SCT (the board's 174 items), all 174.
- System: Kit Laptop (a laptop-size model; measured on a rented GPU with the same weights), Deep Cove Intelligence, Inc. Run Date: 21 November 2026 (UTC).
- Settings: live web search on; one attempt per item.
- Grader: the benchmark's own parser and scorer, run locally; no judge model is called.
- Score: 68.4 mean panel credit (172 graded of 174 ids); Recompute: 100 x (sum of grade) / (number of rows with a grade).
- Rows: 174 ids, 172 valid, 0 void, 2 ungraded.
- Median seconds per item (answered rows): 69.6 seconds.
- Two of the 174 answers carried no rating marker, so the board's own parser scored nothing for them; they are ungraded here and the score is the mean credit over the 172 it parsed.
- Files: README.md (this file), results.csv, results.jsonl and SHA256SUMS. In the rows: item_id = the board's own item id; kit_answer = the answer delivered as text, unchanged; grade = the board's own normalised credit for the answer, from its panel ratings (0 to 1); empty when the board's parser scored nothing; rating_literal = the board's own rating marker for the answer; correct = whether the answer earned its top rating; status = valid, void or ungraded; void_reason = why a void row is void; seconds = the wall-clock seconds the item took. SHA256SUMS covers README.md, results.csv and results.jsonl.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.