# PhysicianBench: Audit Pack

- Benchmark: PhysicianBench, Stanford AIMI (paper arXiv 2605.02240; code https://github.com/HealthRex/PhysicianBench, Apache-2.0; patient record server distributed by Stanford AIMI under the Stanford research data use agreement, DOI 10.57761/1s4z-j007). All 100 tasks, run twice independently (200 task runs).
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: the benchmark's record tools; one attempt per task in each run.
- Count: 100 tasks x 2 runs = 200 scored task runs.
- Grader: the benchmark's official verifier, unmodified, with the verifier's standard judge model GPT-5 for its judged checkpoints. A task run passes only when every one of its checkpoints passes.
- Score: 42.5 (85 of 200 task runs pass every checkpoint). Recompute: 100 x (rows with grade = 1) / 200 over results.jsonl. checks_passed / checks_total give the checkpoint detail for every run.
- Files: results.jsonl and results.csv (item_id = the task folder name in tasks/v1; repeat = run 1 or 2; grade 1 = all checkpoints pass); actions.jsonl (the sequence of record tools Kit called; under the data use agreement no patient data is included); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
