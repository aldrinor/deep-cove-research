# physicianbench: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Opus 5.5 | 44.0 | Deep Cove run, November 2026 (44 of 100) | the same 100 public tasks Kit answered | one run per task (100 scored runs) | the official verifier with its standard judge, as for Kit |
| OpenAI | GPT-6.1 Sol | 36.0 | Deep Cove run, November 2026 (36 of 100) | same | same | same |
