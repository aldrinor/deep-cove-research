# medcasereasoning: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Opus 5.5 | 59.3 | Deep Cove run, 13 November 2026 (89 of 150) | the same 150 cases Kit answered | one run per case, high effort; web search and page-reading tools available, used on none of the 150 cases | the same diagnosis-matching prompt as Kit, scored by a different judge model from Kit's GPT-4.1 |
| OpenAI | GPT-6.1 Sol | 86.7 | Deep Cove run, 13 November 2026 (130 of 150) | same | one run per case, high reasoning effort, with its own live web search; its answers linked the case's own source article in 82 of 150 cases (counted from the answer text) | same |
