# MedCaseReasoning: Audit Pack

- Benchmark: MedCaseReasoning, Wu et al. (arXiv 2505.11733; data https://huggingface.co/datasets/zou-lab/MedCaseReasoning). 150 cases drawn at random (seed 103) from the 897-case test split, after excluding the 60 cases whose final diagnosis appears verbatim in the case text.
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 18–19 November 2026 (UTC).
- Settings: live web search on, as in the product; one attempt per case.
- Grader: GPT-4.1 with the diagnosis-matching prompt in grader/judge_prompt.md: Kit's first-ranked diagnosis is correct when it names the same disease as the published final diagnosis (synonyms and eponyms accepted; broader or narrower categories not accepted). The benchmark publishes no scoring code, so the judge and prompt are given here.
- Score: 71.3 (107 of 150). Recompute: 100 x (rows with grade = 1) / 150.
- Source access: in 54 of the 150 cases a page Kit read, or Kit's answer, named the case's own published source article (source_article_reached = true); 48 of those 54 are correct. On the other 96 cases the score is 61.5 (59 of 96).
- Files: results.jsonl and results.csv (item_id = the case's PMC id; kit_answer = Kit's delivered answer; grade 1 = correct; matching_rank = the rank of the first matching diagnosis in Kit's list; source_article_reached); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
