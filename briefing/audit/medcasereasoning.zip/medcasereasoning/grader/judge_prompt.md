You are a medical diagnosis matching judge for an evaluation. Do not browse.

FINAL DIAGNOSIS (the confirmed diagnosis of the published case):
{gold}

CANDIDATE DIAGNOSES (ranked list):
{candidates}

For each candidate, decide whether it matches the final diagnosis. A match means the same disease entity, allowing accepted synonyms, eponyms, abbreviations and spelling variants. A broader parent category or a narrower subtype does NOT match unless it is a clinically accepted alternative name for the same disease.

Return only a JSON object, no prose:
{"matches": [true or false, ...]}

The array must have exactly {n} entries, one per candidate in the order given.
