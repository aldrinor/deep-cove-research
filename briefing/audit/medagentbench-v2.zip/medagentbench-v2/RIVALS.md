# medagentbench-v2: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Fable 5 | 58.7 | ARISE MAST leaderboard, arise-ai.org/mast (page data of 12 October 2026) | MAST MedAgentBench v2 set | each model inside MAST's standard agent | MAST |
| Anthropic | Opus 5 | 57.0 | same | same | same | MAST |
| OpenAI | GPT-5.6 Sol | 59.7 | same | same | same | MAST |
