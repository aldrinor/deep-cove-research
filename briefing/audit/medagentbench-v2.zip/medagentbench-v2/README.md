# MedAgentBench v2: Audit Pack

- Benchmark: MedAgentBench v2, ARISE Network (MAST). Code and tasks: https://github.com/ARISENetwork/medagentbenchv2 at commit 866dd9e, new_patient_tasks.json, our 100 tasks (10 cases x the 10 task types; ids in ids.txt).
- System: Kit Think, engine head recall14 (code 1f6236347) with the live b8u314i switch set plus 7 record switches (not yet a live release), Deep Cove Intelligence, Inc. Run Dates: 19 November 2026 (UTC).
- Settings: each task's patient record is printed by our converter as a paper chart PDF and uploaded to Kit as a file; Kit answers in the benchmark's action format, the benchmark's checker grades those requests and the FINISH as if they had been sent to its record server, and one attempt per task is made (pass@1).
- Timing: median 104 s per task (p90 141 s), from upload to the delivered answer.
- Grader: the benchmark's checker new_refsol.py, unmodified. SHA-256: 820e59720cf1a70c91612f91391433adfd8940040619a32ab66ff82103687876.
- Score: 88.0 (88 of 100 tasks pass). Recompute: 100 x (rows with grade = 1) / 100 over results.jsonl.
- Files: results.jsonl and results.csv (item_id = the task id in new_patient_tasks.json; kit_answer = Kit's final FINISH(...) output; grade 1 = pass); actions.jsonl (every request Kit wrote in its answer, in order; no server responses); ids.txt (the 100 task ids); run.json (engine, code, run dates, counts, timings); SHA256SUMS.
- Previous run: previous-run/ holds the earlier published pack, unchanged (300 tasks through the benchmark's record tools, 246 pass = 82.0); it is not part of this score.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
