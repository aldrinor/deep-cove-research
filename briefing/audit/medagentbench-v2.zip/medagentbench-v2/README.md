# MedAgentBench v2: Audit Pack

- Benchmark: MedAgentBench v2, ARISE Network (MAST). Code and tasks: https://github.com/ARISENetwork/medagentbenchv2 at commit 866dd9e, new_patient_tasks.json, all 300 tasks (10 task types x 30).
- System: Kit Think, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: the benchmark's FHIR record tools (GET/POST); one attempt per task (pass@1).
- Grader: the benchmark's checker new_refsol.py, unmodified. SHA-256: 820e59720cf1a70c91612f91391433adfd8940040619a32ab66ff82103687876.
- Score: 82.0 (246 of 300 tasks pass). Recompute: 100 x (rows with grade = 1) / 300 over results.jsonl.
- Files: results.jsonl and results.csv (item_id = the task id in new_patient_tasks.json; kit_answer = Kit's final FINISH(...) output; grade 1 = pass); actions.jsonl (every request Kit sent, in order; no server responses); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rival sources: RIVALS.md lists the source, date, item set, settings and grader behind every rival cell shown for this board.
