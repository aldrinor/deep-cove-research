# mast-cpc-images: Rival Sources

Each row is one rival cell in the briefing's score table (or a note shown with it): who produced the figure, on which items, with which settings and grader. Rows marked “Deep Cove run” are Deep Cove Intelligence's own runs of that model on the same items Kit answered; all others are published figures.

| Column | Model | Score | Source and date | Item set | Settings | Grader |
|---|---|---|---|---|---|---|
| Anthropic | Opus 4.7 | 72.7 | ARISE MAST page data, read November 2026 | MAST's full image question set; Kit ran the 337 whose images are public | as published | exact match |
| OpenAI | GPT-5.5 | 90.0 | same | same | same | same |
