# MAST CPC Image Questions: Audit Pack

- Benchmark: CPC-Bench image questions (task image_vqa; Buckley et al., arXiv 2509.12194), as used in the ARISE Network MAST leaderboard: all 337 questions whose images are included in the public release (the question file lists 1,173; the remainder have no image in the public release).
- System: Kit Think with its image understanding, Deep Cove Intelligence, Inc. Run Dates: 14–15 November 2026 (UTC).
- Settings: each question's image sent with the question; one attempt per question.
- Grader: the harness's own exact-match scorer (no judge model): Kit's option letter against the gold letter.
- Score: 81.3 (274 of 337). Recompute: 100 x (rows with grade = 1) / 337.
- Files: results.jsonl and results.csv (item_id = the official question id, <case>_q<n>; kit_answer = Kit's delivered answer; grade 1 = correct); SHA256SUMS.
- Every item was scored as delivered; no answer was edited, re-run or removed after grading.
- Rebuilt 2026-11-16: the answer column now shows Kit's answer; grades unchanged.
